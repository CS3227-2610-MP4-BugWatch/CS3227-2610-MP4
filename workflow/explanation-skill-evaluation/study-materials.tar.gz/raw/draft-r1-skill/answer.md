You can still open or delete your draft when its project is archived. The draft remains private to you as the owning Tester. You cannot save edits or submit the report to that archived project.

To move the draft, select a different active project and save it. Archiving a project does not move its drafts automatically. A project is required from the first save, but the title and other report fields may be blank, subject to field length limits. After a successful save, **Save draft** keeps you on the form and shows **Draft saved**.

If you leave with unsaved edits, you can choose **Keep editing** or **Leave without saving**. Choosing **Leave without saving** preserves only the last saved version; your unsaved changes will be lost. This also means that selecting a new project does not move the draft until you successfully save.

These are the documented rules, not results from a fresh UI or database check. References: `docs/userGuide/Reports.md` and `src/features/reports/database/007_report_drafts.sql`.