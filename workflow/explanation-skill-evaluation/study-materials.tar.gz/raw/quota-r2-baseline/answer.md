`reserve_tester_suggestion_attempt` reserves quota for a Tester before the API contacts the provider. It requires a Tester profile and allows at most 5 attempts per Tester within a rolling 5-minute window. Only `service_role` has permission to execute the database function; an ordinary browser user does not.

A database row lock protects both checking and reserving the same Tester’s quota. This means simultaneous requests cannot all see an empty quota and reserve independently. With 10 simultaneous requests and no recent attempts, exactly 5 are admitted, assuming no attempts expire during those requests. The remaining requests find the quota full; the function does not admit a sixth attempt.

The function reads database time after obtaining the lock. It keeps timestamps strictly newer than `checked_at` minus 5 minutes. For example, if `checked_at` is 12:05:00, an attempt at exactly 12:00:00 has expired, while one just after 12:00:00 still counts.

When the quota is full, the caller receives `allowed=false` and `retryAfterMs`, a wait duration in milliseconds. An admitted reservation is not refunded if the subsequent provider call fails.

These rules come from source inspection of `src/features/reports/database/010_tester_suggestion_quota_five.sql` and `api/tester/report-suggestions.ts`. This writing trial has not executed a database concurrency test.