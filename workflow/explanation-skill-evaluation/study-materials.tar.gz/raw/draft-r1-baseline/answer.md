You can still open or delete your draft when its project is archived, but you cannot save edits or submit it to that archived project. The draft remains private to you as its owning Tester.

To keep working on it, select a different active project and save. That save moves the draft to the selected project; archiving the original project does not move it automatically. A project is required from the first save, but the title and other report fields may be blank, subject to field length limits. After a successful save, you stay on the form and see “Draft saved.”

If you leave with unsaved edits, you can choose “Keep editing” or “Leave without saving.” Leaving without saving preserves only the last saved version, so any changes made since that save are lost. For example, if you select an active project but leave without saving, the draft has not moved.

These are the documented rules; this writing trial has not opened the UI or executed the database to verify them.