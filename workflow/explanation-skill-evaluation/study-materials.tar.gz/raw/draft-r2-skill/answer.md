You can still open or delete your draft when its project is archived. The draft remains private to you as the owning Tester. However, saving edits or submitting it to the archived project is rejected.

To move the draft, select a different active project and save. Archiving a project does not automatically move its drafts. After a successful save, you stay on the form and see **Draft saved**. A project is required from the first save, but the title and other report fields can be blank, subject to field length limits.

If you leave with unsaved edits, you can choose **Keep editing** or **Leave without saving**. Leaving preserves only the last saved version. For example, if you select an active project but leave before saving, that project change is not preserved.

These are the documented rules; this writing trial has not opened the UI or executed the database.

References: `docs/userGuide/Reports.md`, `src/features/reports/database/007_report_drafts.sql`.