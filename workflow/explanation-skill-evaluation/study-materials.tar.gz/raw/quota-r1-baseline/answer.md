`reserve_tester_suggestion_attempt` reserves a suggestion attempt for a Tester, allowing at most 5 attempts per Tester in a rolling 5-minute window. It requires a Tester profile, and its execute grant is limited to `service_role`; an ordinary browser user cannot execute it directly.

A database row lock protects both checking and reserving the same Tester’s quota. That makes simultaneous requests take turns at this step. If 10 requests arrive with no recent attempts, the first 5 each reserve a slot. The remaining 5 find the quota full and are rejected. Exactly 5 are admitted, assuming no attempts expire during those requests.

The function reads database time after obtaining the lock. It retains only timestamps strictly newer than `checked_at` minus 5 minutes, so an attempt exactly at that cutoff has expired and no longer counts.

When the quota is full, the function returns `allowed=false` and `retryAfterMs`, a wait duration in milliseconds. It does not admit a sixth attempt.

The API reserves an attempt before contacting the provider. If that provider call subsequently fails, the reservation is not refunded.

These rules were established by source inspection; this writing trial has not executed a database concurrency test.