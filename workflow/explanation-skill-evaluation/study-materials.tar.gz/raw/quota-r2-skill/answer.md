`reserve_tester_suggestion_attempt` reserves a suggestion attempt before the API contacts the provider. It requires a Tester profile and allows at most 5 attempts per Tester in a rolling 5-minute window. Only `service_role` has permission to execute it; an ordinary browser user does not.

A database row lock protects the quota check and reservation for the same Tester. This means simultaneous requests cannot each see an empty quota and reserve independently. With 10 simultaneous requests and no recent attempts, exactly 5 are admitted, assuming no attempts expire during those requests. The remaining 5 find the quota full.

The function reads database time after obtaining the lock. It keeps only timestamps strictly newer than `checked_at` minus 5 minutes. An attempt exactly at that cutoff has expired and no longer counts toward the limit.

When the quota is full, the function returns `allowed=false` and `retryAfterMs`, the wait duration in milliseconds. It does not admit a sixth attempt. If an admitted request later fails when contacting the provider, its reservation is not refunded.

These rules come from source inspection of [the database function](src/features/reports/database/010_tester_suggestion_quota_five.sql) and [the API](api/tester/report-suggestions.ts). This writing trial has not executed a database concurrency test.