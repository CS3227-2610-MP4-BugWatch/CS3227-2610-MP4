The tests check that the experiment reporter makes reduction claims only when usage is valid and the required acceptance checks pass. They exercise `summarizeExperiment` and its local Node CLI with synthetic records.

Unknown usage (`null`), known usage and observed zero need separate cases because they represent different states. Zero records no usage; `null` means usage is unknown. Turning `null` into zero could make missing data look like a reduction. Groups expected to behave alike are called equivalence partitions.

Numeric boundary tests check the limits of valid counters. Each token counter must be a nonnegative safe integer. Negative numbers, fractions, `NaN`, `Infinity` and values above `Number.MAX_SAFE_INTEGER`—9,007,199,254,740,991—must be rejected. Even individually valid counters can produce an unsafe sum, which must also be rejected. Cached input cannot exceed total input. Because total input already includes cached input, the reporter must not add it twice.

Unsuccessful acceptance checks need separate cases because lower usage alone does not justify a reduction claim. A required check marked `failed`, `skipped` or `not_run` must withhold that claim. Separate negative cases make it easier to identify which rule failed.

Passing these tests checks reporter behavior on the supplied cases. It does not prove that the writing skill improves human understanding or saves charges.

References: `src/test/workflow-evaluation.test.ts`, `workflow/evaluation/summarizeExperiment.ts`.