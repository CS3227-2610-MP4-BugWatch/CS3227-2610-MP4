The test design checks that the experiment reporter keeps distinct states separate, rejects invalid arithmetic, and makes reduction claims only when required acceptance checks pass. The tests exercise `summarizeExperiment` and its local Node CLI using synthetic records.

Known usage, unknown usage (`null`), and observed zero are separate groups because they mean different things. Zero records no usage; `null` means usage is unknown and must not become zero. Groups expected to behave alike are called equivalence partitions.

Numeric tests check both invalid inputs and boundary values. Token counters must be nonnegative safe integers: negative, fractional, `NaN`, `Infinity`, and values above `Number.MAX_SAFE_INTEGER` are rejected. That maximum is 9,007,199,254,740,991. Individually valid counters can still produce an unsafe sum, which must also be rejected. Cached input cannot exceed total input, and it is already included in total input, so adding it again would double-count it.

Acceptance tests check a separate condition: lower usage alone does not justify a reduction claim. Required checks marked `failed`, `skipped`, or `not_run` must withhold that claim. Keeping negative cases separate makes it easier to diagnose which rule failed; testing edge values checks the boundaries of allowed behavior.

Passing these tests checks reporter behavior on the supplied cases. It does not prove that the writing skill improves human understanding or saves charges.