`reserve_tester_suggestion_attempt` reserves an attempt before the API contacts the provider. It requires a Tester profile and allows at most 5 attempts per Tester within a rolling 5-minute window. Only `service_role` has permission to execute it; an ordinary browser user does not.

A database row lock protects both checking and reserving the same Tester’s quota. Requests for that Tester must take turns through this protected step. With no recent attempts, the first 5 requests each reserve a place. The remaining 5 find the quota full and are rejected. Thus, 10 simultaneous requests admit exactly 5, assuming no attempts expire during those requests.

The function reads database time after obtaining the lock. It retains only timestamps strictly newer than `checked_at` minus 5 minutes. An attempt exactly at that cutoff has expired and no longer counts.

When the quota is full, the function returns `allowed=false` and `retryAfterMs`, a wait duration in milliseconds. It does not admit a sixth attempt. If an admitted request’s subsequent provider call fails, its reservation is not refunded.

These rules come from source inspection of [the database function](src/features/reports/database/010_tester_suggestion_quota_five.sql) and [the API](api/tester/report-suggestions.ts). This writing trial has not executed a database concurrency test.