The tests check whether the experiment reporter handles usage correctly and withholds reduction claims when required acceptance checks are unsuccessful. They exercise `summarizeExperiment` and its local Node CLI with synthetic records.

Unknown usage (`null`), known usage and observed zero need separate cases because they mean different things. Zero is an observed amount; `null` means the amount is unknown. Converting `null` to zero would make missing information look like measured usage.

Numeric tests check both invalid counters and limits. Token counters must be nonnegative safe integers, so negative, fractional, `NaN`, `Infinity` and values above `Number.MAX_SAFE_INTEGER`—9,007,199,254,740,991—are rejected. Individually valid counters can still produce an unsafe sum, which must also be rejected. Cached input cannot exceed total input. Because cached input is already included in total input, the reporter must not add it twice.

Acceptance tests check a separate condition: lower usage alone is insufficient for a reduction claim. A required check marked `failed`, `skipped` or `not_run` must withhold that claim.

Separate negative cases make the failing rule easier to identify. Groups expected to behave alike are called equivalence partitions; tests at edge values are boundary tests.

Passing these tests supports reporter behavior on the supplied cases. It does not prove that the writing skill improves human understanding or saves charges.

Source references: `src/test/workflow-evaluation.test.ts`, `workflow/evaluation/summarizeExperiment.ts`.