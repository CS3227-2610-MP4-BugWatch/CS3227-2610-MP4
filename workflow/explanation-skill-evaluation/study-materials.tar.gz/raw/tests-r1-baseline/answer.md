The tests separate unknown usage, numeric limits and unsuccessful acceptance checks because each can make the experiment reporter reach a misleading conclusion for a different reason. They exercise `summarizeExperiment` and its local Node CLI using synthetic records.

Known usage, unknown usage (`null`) and observed zero are distinct states. Zero means no usage was observed; `null` means usage is unknown. Testing them separately checks that missing information does not become zero. Groups expected to behave alike are called equivalence partitions.

Numeric tests check both valid limits and invalid inputs. Token counters must be nonnegative safe integers, so negative numbers, fractions, `NaN`, `Infinity` and values above `Number.MAX_SAFE_INTEGER` are rejected. That maximum is 9,007,199,254,740,991. Even individually valid counters can produce an unsafe sum, which must also be rejected. Edge values are boundary tests. Separate cases also check that cached input cannot exceed total input and, because it is already included in total input, is not added twice.

Acceptance tests check a separate condition: lower usage alone does not justify a reduction claim. If a required acceptance check is `failed`, `skipped` or `not_run`, the reporter must withhold that claim. Keeping negative cases separate makes the failing rule easier to diagnose.

Passing these tests checks reporter behavior on the supplied cases. It does not prove that the writing skill improves human understanding or saves charges.

Source references: `src/test/workflow-evaluation.test.ts`, `workflow/evaluation/summarizeExperiment.ts`.