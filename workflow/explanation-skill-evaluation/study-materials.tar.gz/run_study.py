"""Run the frozen local writing study; never edit answers or infer missing usage."""
import argparse
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tempfile
import time


HERE = Path(__file__).resolve().parent


def digest(value):
    return hashlib.sha256(value).hexdigest()


def run_one(study, case, repetition, condition, order):
    run_id = f"{case['id']}-r{repetition}-{condition}"
    target = HERE / 'raw' / run_id
    target.mkdir(parents=True, exist_ok=True)
    manifest = target / 'manifest.json'
    if manifest.exists():
        return json.loads(manifest.read_text(encoding='utf-8'))
    prompt = study['commonInstructions'] + '\n\n'
    if condition == 'skill':
        prompt += 'Additional writing guidance for this run:\n' + study['frozenSkillText'] + '\n\n'
    prompt += 'SOURCE FACT SHEET:\n'
    prompt += '\n'.join(f"- {text}" for _, text in case['facts'])
    prompt += '\nSource references: ' + ', '.join(case['sources'])
    prompt += '\n\nUSER REQUEST:\n' + case['prompt']
    (target / 'prompt.txt').write_text(prompt, encoding='utf-8')
    clean = tempfile.mkdtemp(prefix='bugwatch-explanation-trial-')
    args = [shutil.which('codex') or 'codex', 'exec', '--ignore-user-config', '--strict-config',
            '--ephemeral', '--skip-git-repo-check', '--json', '--color', 'never',
            '--sandbox', 'read-only', '--cd', clean, '--model', study['model'],
            '--config', f"model_reasoning_effort=\"{study['reasoningEffort']}\"",
            '--config', 'project_doc_max_bytes=0', '--config', 'web_search="disabled"',
            '--output-last-message', str(target / 'answer.md'), '-']
    started = datetime.now(timezone.utc).isoformat()
    begin = time.perf_counter()
    try:
        completed = subprocess.run(args, input=prompt, encoding='utf-8', errors='replace',
                                   capture_output=True, timeout=120,
                                   creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        stdout, stderr, code = completed.stdout, completed.stderr, completed.returncode
    except subprocess.TimeoutExpired as error:
        stdout = error.stdout or b''
        stderr = error.stderr or b''
        if isinstance(stdout, bytes):
            stdout = stdout.decode('utf-8', errors='replace')
        if isinstance(stderr, bytes):
            stderr = stderr.decode('utf-8', errors='replace')
        stderr += '\nRunner timeout at 120 seconds; no successful completion claimed.'
        code = 124
    elapsed = round((time.perf_counter() - begin) * 1000)
    events, usage, tools = [], None, []
    malformed = 0
    for line in stdout.splitlines():
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            malformed += 1
            continue
        item = event.get('item', {})
        kind = item.get('type')
        if kind == 'reasoning':
            event['item'] = {'type': kind, 'contentOmitted': 'reasoning text is not report evidence'}
        elif kind and kind not in ('agent_message', 'reasoning'):
            tools.append(kind)
        if event.get('type') == 'turn.completed':
            usage = event.get('usage')
        events.append(event)
    (target / 'events.jsonl').write_text(''.join(json.dumps(e, ensure_ascii=False) + '\n' for e in events), encoding='utf-8')
    home = str(Path.home())
    stderr = stderr.replace(home, '%USERPROFILE%').replace(home.replace('\\', '/'), '%USERPROFILE%')
    (target / 'stderr.txt').write_text(stderr, encoding='utf-8')
    answer_path = target / 'answer.md'
    answer = answer_path.read_text(encoding='utf-8') if answer_path.exists() else ''
    result = {'runId': run_id, 'taskId': case['id'], 'repetition': repetition,
              'condition': condition, 'order': order, 'startedUtc': started,
              'elapsedMs': elapsed, 'exitCode': code, 'configuredModel': study['model'],
              'reasoningEffort': study['reasoningEffort'], 'usage': usage,
              'toolEvents': tools, 'nonJsonLines': malformed,
              'controlledSuccess': code == 0 and bool(answer.strip()) and not tools and malformed == 0,
              'answerWordsWhitespace': len(answer.split()), 'answerSha256': digest(answer.encode()),
              'promptSha256': digest(prompt.encode()),
              'studySha256': digest((HERE / 'study.json').read_bytes()),
              'answerPath': str(answer_path.relative_to(HERE)).replace('\\', '/'),
              'traceNote': 'JSON events retained; reasoning text omitted and user-home paths in stderr redacted.'}
    manifest.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(f"{run_id}: exit={code}, controlled={result['controlledSuccess']}, words={result['answerWordsWhitespace']}, elapsedMs={elapsed}", flush=True)
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--limit', type=int, default=None)
    options = parser.parse_args()
    if options.limit is not None and options.limit < 1:
        parser.error('--limit must be positive')
    data = (HERE / 'study.json').read_bytes()
    if digest(data) != (HERE / 'study.sha256').read_text().strip():
        raise ValueError('Frozen study hash mismatch; do not change the protocol after generation')
    study = json.loads(data)
    pairs = []
    for repetition in range(1, study['repetitions'] + 1):
        for index, case in enumerate(study['cases']):
            conditions = ('baseline', 'skill') if (index + repetition) % 2 else ('skill', 'baseline')
            pairs.append([(case, repetition, condition, order) for order, condition in enumerate(conditions, 1)])
    if options.limit is not None:
        flat = [run for pair in pairs for run in pair][:options.limit]
        results = [run_one(study, *run) for run in flat]
    else:
        def pair_job(pair):
            return [run_one(study, *run) for run in pair]
        with ThreadPoolExecutor(max_workers=2) as executor:
            results = [run for group in executor.map(pair_job, pairs) for run in group]
    (HERE / 'results.json').write_text(json.dumps({'studyId': study['id'], 'runs': results}, indent=2) + '\n', encoding='utf-8')
    if not all(run['controlledSuccess'] for run in results):
        raise SystemExit('One or more unsuccessful/uncontrolled runs retained; do not claim a complete controlled comparison.')


if __name__ == '__main__':
    main()
