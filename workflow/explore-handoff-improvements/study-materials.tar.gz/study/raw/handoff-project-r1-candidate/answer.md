Implement P2 under [feature-plan.md](workflow/project-revision-exercise/feature-plan.md), revision 2, using design interface I2 and requirements R4–R8.

Read `code-standards.md` and `handoffs.md` before editing. Consult the relevant plan/interface sections; retrieve additional context if a dependency or failure requires it. Authentication provisioning, report form labels and MarkBind navigation are outside this task.

**Ownership and scope**

You own only `src/features/projects/projectRepository.ts`. Preserve other agents’ edits. The tester owns `src/test/project-revision.test.ts`; the coordinator owns SQL, types and shared configuration. Do not change SQL, types, public interfaces, UI, role policy or dependencies. Route ownership conflicts and required changes outside your file to the coordinator.

**Required contract**

Preserve the caller-facing signature `ProjectRepository.updateProject(id,expectedRevision,input)` and its `update_project` RPC call with these exact parameters:

- `p_project_id`
- `p_expected_revision`
- `p_name`
- `p_description`
- `p_repository_url`

Forward the exact expected revision and return the decoded saved `Project`. Use the decoder contract specified by I2 and the relevant source. If that contract is missing or unclear, resolve it with the coordinator before implementation.

Map RPC error `P1007` to a `ProjectError` with code `conflict` and the exact safe message: `Project changed. Reload and try again.` Do not automatically retry a write or overwrite concurrent edits. Preserve existing authentication and archive error handling, keep session-boundary handling in the existing wrapper, and never expose raw database messages.

**Checks and evidence**

Coordinate with the tester without editing their file. Required coverage is exact expected-revision forwarding, returned-row decoding, conflict mapping, no automatic retry and no raw SQL-message leakage.

Run these checks when prerequisites and the tester’s current state permit:

```text
npm run test -- --run src/test/project-revision.test.ts
npm run lint
npm run build
```

Report actual commands and outcomes, distinguishing executed, skipped and blocked checks. No executed results are supplied by this assignment.

**Handoff**

Return submission `PROJECT-IMPL-1` at `revision2`, identifying changed files, implemented behavior, actual verification results, assumptions, risks and blockers. Follow `workflow/templates/implementer-summary-template.md` for materially changed functions: explain purpose, inputs/results, side effects, failures/recovery and linked tests.

Your completion report awaits independent reviewer approval; do not claim approval yourself. The coordinator updates the shared plan and check boxes. After approval, write only the post-approval summary file explicitly assigned by the coordinator.