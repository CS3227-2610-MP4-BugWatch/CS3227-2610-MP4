The supplied source facts establish that only Testers create reports, reports belong to one active project, and archived projects cannot receive saves or submissions. Selecting a different active project is technically possible.

The confirmed simulated stakeholder decisions are that drafts stay private to their owning Tester and require a project from the first save; ungrouped drafts are excluded.

For the ordinary flow, a Tester starts a report in an active project, works on it, and may need to move the unfinished report to another active project. The first unresolved choice is how their work gets saved.

**Should unfinished reports save automatically as the Tester works, or only when they explicitly choose “Save draft”?** I recommend automatic saving because avoiding lost work is your stated goal. Explicit saving gives the Tester more control over when a draft is saved, but leaves changes at risk between saves. This choice will shape what happens when they switch projects or leave the page, so we should settle it before navigation-warning details.