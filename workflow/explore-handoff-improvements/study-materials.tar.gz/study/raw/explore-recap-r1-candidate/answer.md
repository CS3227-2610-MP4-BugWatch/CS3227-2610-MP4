We’ve agreed in this simulation that testers can explicitly save private, project-specific drafts from the first save. Other draft fields may be blank within existing limits. Saving keeps the tester on the form and displays **Draft saved** on success.

For archived projects, existing drafts remain readable and deletable. Saving edits or submitting to the archived project is rejected, but the owner can select another active project and save to move the draft.

If the connection fails, the current text is retained for correction, readback or retry as appropriate. There is no silent automatic repost.

Attachments, shared drafts and automatic saving are excluded. Only exploration and recap are authorized; no files or implementation are authorized.

The remaining decision is navigation with unsaved edits. A warning before leaving is an **unconfirmed recommendation**, not an agreed requirement. I recommend it because it gives testers a chance to avoid losing changes, at the cost of an extra prompt when leaving.

**Should testers be warned before leaving the form with unsaved edits?** That decision is needed before the proposal can fully describe the navigation experience.