We’ve agreed that Tester drafts are private and tied to a project from the first save. Other fields may remain blank within existing limits.

Saving is explicit: **Save draft** keeps the user on the form and shows **Draft saved** on success. Connection failures retain the current text for correction, readback or retry as appropriate, with no silent automatic repost.

Drafts in archived projects remain readable and deletable. Saving edits or submitting to that project is rejected, but the owner can select another active project and save to move the draft.

Attachments, shared drafts and automatic saving are out of scope.

The remaining decision before a complete proposal is how navigation should behave with unsaved edits. A warning was recommended, but you haven’t accepted or rejected it.

Should leaving the form with unsaved edits trigger a warning? I recommend it to help prevent accidental loss while keeping saving explicit.