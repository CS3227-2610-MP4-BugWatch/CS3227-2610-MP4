You want Testers to keep unfinished reports safe and sometimes move them to another project before submitting.

The supplied source facts establish that only Testers create reports, submitted reports belong to one active project, and archived projects cannot receive saves or submissions. Selecting a different active project is technically possible.

The simulated stakeholder decisions already establish that drafts are private to their owning Tester and require a project from the first save; ungrouped drafts are excluded.

The first choice is how saving should feel. For example, if you type a report and leave the page before clicking anything, should those edits already be saved? That choice determines when navigation warnings would help and what users can expect to recover.

I recommend automatic saving because your main goal is avoiding lost work. The trade-off is that incomplete edits are retained without a deliberate save action; explicit saving gives you more control but leaves a gap where edits could be lost.

**Should drafts save automatically as you work, or only when you explicitly choose “Save draft”?**