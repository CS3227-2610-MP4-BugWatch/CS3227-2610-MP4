Implement P2 under [feature-plan.md](workflow/project-revision-exercise/feature-plan.md), **revision 2**, using design interface **I2** and requirements **R4–R8**.

**Outcome and contract**

Update the repository adapter while preserving the caller-facing signature `ProjectRepository.updateProject(id, expectedRevision, input)`.

- Call `update_project` with `p_project_id`, `p_expected_revision`, `p_name`, `p_description`, and `p_repository_url`. Forward the exact supplied expected revision.
- Decode the returned saved row into a `Project` using the authoritative decoder contract. If that contract is missing or unclear, resolve it with the coordinator before implementation.
- Map `P1007` to `ProjectError` with code `conflict` and the exact safe message: `Project changed. Reload and try again.`
- Do not automatically retry writes or overwrite concurrent edits.
- Preserve existing authentication and archive error handling. Do not expose raw database messages. Keep session-boundary handling in the existing wrapper.

**Context and ownership**

Read `code-standards.md` and `handoffs.md`, and consult the relevant I2 interface rather than copying the whole project specification. Retrieve additional necessary context when a dependency or failure requires it; report gaps rather than guessing.

You own **`src/features/projects/projectRepository.ts` only**. The tester owns `src/test/project-revision.test.ts`; the coordinator owns SQL, types, and shared configuration. Preserve other agents’ edits and route ownership conflicts to the coordinator. No SQL, type/public-interface, UI, role-policy, or dependency changes are in scope. Authentication provisioning, report form labels, and MarkBind navigation are unrelated to P2.

**Checks and evidence**

Run and report actual outcomes for:

```text
npm run test -- --run src/test/project-revision.test.ts
npm run lint
npm run build
```

Coordinate with the tester on coverage for exact expected-revision forwarding, returned-row decoding, conflict mapping, no automatic retry, and no raw SQL leakage. Distinguish executed checks from pending, skipped, or blocked checks; no executed results are supplied.

**Return**

Submit **`PROJECT-IMPL-1` at `revision2`** to the coordinator using `workflow/templates/implementer-summary-template.md`. Identify changed files and materially changed functions, explaining their purpose, inputs/results, side effects, failure/recovery behavior, linked tests, actual verification outcomes, and unresolved risks or blockers.

Your completion report awaits independent reviewer approval. Do not update the shared plan or checkboxes, or create a competing workflow log; the coordinator owns those records. After approval, write only your coordinator-assigned post-approval summary file.