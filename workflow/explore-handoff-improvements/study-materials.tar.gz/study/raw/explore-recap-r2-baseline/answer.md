We’ve agreed that tester drafts are private and tied to a project from the first save. Other fields may be blank within existing limits.

Saving is explicit: **Save draft** keeps the tester on the form and shows **Draft saved** on success. Connection failures retain the current text for correction, readback or retry as appropriate, with no silent automatic repost.

Drafts in archived projects remain readable and deletable. Saving edits or submitting to the archived project is rejected, but the owner can select a different active project and save to move the draft.

Attachments, shared drafts and automatic saving are out of scope. This remains exploration only; no file writing or implementation is authorized.

The remaining blocker before a complete proposal is navigation with unsaved edits. I recommended a warning before leaving, but you haven’t accepted or rejected it.

**Should leaving the form with unsaved edits trigger a warning?** I recommend it to help prevent accidental loss while keeping saving explicit.