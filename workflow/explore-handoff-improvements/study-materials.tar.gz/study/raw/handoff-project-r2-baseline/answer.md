Implement P2 against [feature-plan.md](workflow/project-revision-exercise/feature-plan.md), revision 2, using design interface I2 and requirements R4–R8. Read `code-standards.md` and `handoffs.md` before starting; consult the exact relevant interface and retrieve additional context only when needed to resolve a dependency or failure.

You own **`src/features/projects/projectRepository.ts` only**. The tester owns `src/test/project-revision.test.ts`; the coordinator owns SQL, types and shared configuration. Other agents are editing their assigned files. Preserve unrelated changes and do not edit outside your ownership.

Preserve the caller-facing signature `ProjectRepository.updateProject(id,expectedRevision,input)` and its contract:

- Call `update_project` with `p_project_id`, `p_expected_revision`, `p_name`, `p_description` and `p_repository_url`. Forward the supplied expected revision exactly.
- Decode the returned saved row and return the saved `Project`. If the decoder contract is missing or unclear, resolve it with the coordinator before implementation.
- Map `P1007` to `ProjectError` with code `conflict` and the exact safe message `Project changed. Reload and try again.`
- Do not silently retry a write or overwrite concurrent edits. Preserve existing authentication and archive error handling, keep session-boundary handling in the existing wrapper, and never expose raw database messages.

Scope is the repository adapter only: no SQL, type/public-interface, UI, role-policy or dependency changes. Authentication provisioning guidance, report form labels and MarkBind navigation are unrelated to P2.

Coordinate with the tester on coverage for exact expected-revision forwarding, saved-row decoding, conflict mapping, no automatic retry and no raw SQL leakage. Run the following checks where available, reporting actual outcomes and any blockers:

- `npm run test -- --run src/test/project-revision.test.ts`
- `npm run lint`
- `npm run build`

Return completion submission **`PROJECT-IMPL-1` at `revision2`**, identifying changed files, implemented behavior, materially changed functions and their purpose, inputs/results, side effects, failures/recovery, linked tests, actual verification results and remaining risks. Follow `workflow/templates/implementer-summary-template.md` for the handoff content; do not claim unexecuted checks or reviewer approval.

Your submission requires independent reviewer approval. Send blockers promptly. The coordinator updates the shared plan and check boxes; do not edit them or create a separate workflow log. Write your assigned post-approval summary only after the coordinator confirms approval and assigns its unique path.