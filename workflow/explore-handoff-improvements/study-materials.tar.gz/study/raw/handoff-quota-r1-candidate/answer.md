Implement Q1 from `workflow/quota-exercise/feature-plan.md`, revision 3, following requirements R1–R5 and interface I1.

**Read first:** the relevant plan sections, `workflow/instructions/code-standards.md`, and `handoffs.md`. Agree I1 with the tester before parallel edits. Retrieve further relevant context when an interface, failure, or dependency requires it; route missing contracts to the coordinator rather than guessing.

**Ownership:** Exclusively edit `src/features/reports/quotaPolicy.ts`. The tester owns `src/test/quota-policy.test.ts`; root owns shared configuration and task checkboxes. Preserve other writers’ changes and report conflicts. Do not add database access, provider calls, UI changes, or dependencies.

**Required contract:**
```ts
reserveAttempt(
  attempts: readonly number[],
  nowMs: number
): { allowed: boolean; retryAfterMs: number; attempts: number[] }
```

Inputs are epoch milliseconds and admitted timestamps. Do not mutate the caller’s array. Return retained timestamps sorted ascending.

- Retain only timestamps strictly greater than `nowMs - 300000`; a timestamp exactly at the cutoff expires.
- If fewer than 5 remain, append `nowMs` and return `allowed: true`, `retryAfterMs: 0`.
- If already 5 remain, do not append. Return `allowed: false` and `retryAfterMs: Math.max(0, oldest + 300000 - nowMs)`.

This pure helper does not establish atomic admission across concurrent requests; make no concurrency claims.

**Verification:** Coordinate with the tester on empty input, fifth/sixth attempts, exact cutoff, unsorted input, and input immutability. Required checks are:
```text
npm run test -- --run src/test/quota-policy.test.ts
npm run lint
npm run build
```
Report actual commands and outcomes, distinguishing executed, skipped, and blocked checks. No test output is currently supplied.

**Handoff:** Return submission `QUOTA-IMPL-1`, identifying `revision3`, the final work state, changed files, implemented behavior, actual verification, and assumptions or limitations. Follow `workflow/templates/implementer-summary-template.md`: explain materially changed functions’ purpose, inputs/results, side effects, failures/recovery, and linked tests.

Your completion report awaits independent reviewer approval; do not mark shared checkboxes or claim approval. After root confirms approval, write only the post-approval summary at the unique path root assigns.