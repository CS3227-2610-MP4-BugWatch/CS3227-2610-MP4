We’ve established that drafts are private to the Tester who owns them and must have a project from the first save. Reports belong to one active project, and selecting a different active project is technically possible. An archived project cannot accept saves or submissions.

The first choice is how unfinished work gets saved; that will also shape what happens when you navigate away. Given your goal of avoiding lost work, I’d lean toward automatic saving, though explicit saving gives you more control over when a draft is kept.

Would you prefer your unfinished report to save automatically as you work, or only when you choose “Save draft”?