Implement Q1 against `workflow/quota-exercise/feature-plan.md`, revision 3, using requirements R1–R5 and interface I1.

You exclusively own `src/features/reports/quotaPolicy.ts`. Preserve other writers’ changes. The tester owns `src/test/quota-policy.test.ts`; root owns shared configuration and task checkboxes.

Before editing, read the assigned plan and `workflow/instructions/code-standards.md` and `handoffs.md`. Agree I1 with the tester before parallel edits. Retrieve further relevant context as needed; raise missing contracts with the coordinator rather than guessing.

Implement this exact export:

```ts
reserveAttempt(
  attempts: readonly number[],
  nowMs: number
): { allowed: boolean; retryAfterMs: number; attempts: number[] }
```

Acceptance criteria:

- Inputs are epoch milliseconds and admitted timestamps. Do not mutate the caller’s array.
- Retain only timestamps strictly greater than `nowMs - 300000`; timestamps exactly at the cutoff expire. Return retained timestamps sorted ascending.
- If fewer than 5 remain, append `nowMs`, return `allowed: true` and `retryAfterMs: 0`.
- If already 5 remain, do not append. Return `allowed: false` and `retryAfterMs: Math.max(0, oldest + 300000 - nowMs)`.
- Add no database access, provider calls, UI changes or dependencies. Make no concurrency guarantees: this pure helper does not prove atomic multi-request admission.

Coordinate coverage with the tester for empty input, fifth/sixth attempts, exact cutoff, unsorted input and input immutability. Required checks are:

```text
npm run test -- --run src/test/quota-policy.test.ts
npm run lint
npm run build
```

Return completion submission **QUOTA-IMPL-1**, identifying **revision3**, changed files, implemented behaviour, actual commands and results, and unresolved limitations or blockers. Follow `workflow/templates/implementer-summary-template.md` for function purpose, inputs/results, side effects, failures/recovery and linked tests. No test output is supplied yet; do not imply verification has occurred.

Your completion report awaits independent reviewer approval. Report blockers promptly; do not edit shared plans, checkboxes or logs. After the coordinator confirms approval of the latest submission and combined work, write your assigned post-approval summary at `workflow/quota-exercise/implementer-summary.md`. Any subsequent code changes require a new submission and fresh review.