Implement P2 against [feature-plan.md](workflow/project-revision-exercise/feature-plan.md), revision 2, using design interface I2 and requirements R4–R8.

Read `code-standards.md` and `handoffs.md` before starting. Use the relevant interface contract from the plan; retrieve additional context only when needed to resolve a dependency or failure.

You own **`src/features/projects/projectRepository.ts` only**. Preserve unrelated changes. The tester owns `src/test/project-revision.test.ts`; the coordinator owns SQL, types, and shared configuration. Other agents are editing their assigned files.

Preserve the caller-facing signature `ProjectRepository.updateProject(id, expectedRevision, input)`. It must call `update_project` with `p_project_id`, `p_expected_revision`, `p_name`, `p_description`, and `p_repository_url`, then decode the returned saved row into a `Project`. If the decoder contract is missing or unclear, report that dependency to the coordinator and resolve it before implementation.

Map database error `P1007` to a `ProjectError` with code `conflict` and the exact safe message: `Project changed. Reload and try again.` Do not automatically retry writes or overwrite concurrent edits. Preserve existing authentication and archive error handling, keep session-boundary handling in the existing wrapper, and never expose raw database messages.

Acceptance covers exact expected-revision forwarding, returned-row decoding, conflict mapping, no automatic retry, and no raw SQL message leakage. Coordinate coverage with the tester without editing their file. Run and report actual outcomes for:

- `npm run test -- --run src/test/project-revision.test.ts`
- `npm run lint`
- `npm run build`

Keep the work limited to the repository adapter. Do not change SQL, types, public interfaces, UI, role policy, dependencies, authentication provisioning guidance, report form labels, or MarkBind navigation.

Return submission **`PROJECT-IMPL-1` at `revision2`**, identifying changed files, completion status, materially changed functions, purpose, inputs/results, side effects, failure/recovery behavior, linked tests, actual verification outcomes, and unresolved risks or blockers. Follow `workflow/templates/implementer-summary-template.md` for the handoff content. No verification results are supplied; do not claim checks have passed without executing them.

Your completion report awaits independent reviewer approval. The coordinator will route it for review and update the shared plan and check boxes. Do not edit the shared plan or create a separate workflow log. Write your assigned post-approval summary only after the coordinator confirms approval and supplies its unique path.