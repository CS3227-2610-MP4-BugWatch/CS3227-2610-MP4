We’ve confirmed that drafts will be private to the owning Tester and must belong to a project from the first save. You can switch to another active project, but an archived project cannot receive saves or submissions.

The first choice is how saving should feel. I’d lean toward automatic saving to support your goal of avoiding lost work; explicit saving gives you more control but requires remembering to save. We can explore navigation warnings after that choice.

Would you prefer your unfinished report to save automatically as you work, or only when you choose “Save draft”?