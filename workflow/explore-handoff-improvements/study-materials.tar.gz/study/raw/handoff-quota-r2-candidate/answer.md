Implement Q1 against `workflow/quota-exercise/feature-plan.md`, revision 3, using requirements R1–R5 and design interface I1 as authoritative.

Read `workflow/instructions/code-standards.md` and `handoffs.md` before editing. Agree I1 with the tester before parallel edits begin. Retrieve further relevant context when an interface, failure, or dependency requires it; raise missing contracts with the coordinator rather than guessing.

**Ownership:** You exclusively own `src/features/reports/quotaPolicy.ts`. The tester owns `src/test/quota-policy.test.ts`; root owns shared configuration and task checkboxes. Preserve other active writers’ changes and route ownership conflicts to the coordinator. Do not add database or provider calls, UI changes, or dependencies.

**Required contract:**

```ts
reserveAttempt(
  attempts: readonly number[],
  nowMs: number
): { allowed: boolean; retryAfterMs: number; attempts: number[] }
```

Inputs are epoch milliseconds and admitted timestamps. Do not mutate the caller’s array.

- Retain only timestamps strictly greater than `nowMs - 300000`; a timestamp exactly at the cutoff expires. Return retained timestamps sorted ascending.
- If fewer than five remain, append `nowMs` and return `allowed: true`, `retryAfterMs: 0`.
- If five already remain, do not append. Return `allowed: false` and `retryAfterMs: Math.max(0, oldest + 300000 - nowMs)`.

This is a pure helper; do not claim it proves atomic admission across concurrent requests.

**Verification:** Coordinate with the tester on empty input, fifth/sixth admission, exact cutoff, unsorted input, and input immutability. Required checks are:

```text
npm run test -- --run src/test/quota-policy.test.ts
npm run lint
npm run build
```

No test output has been supplied. Report executed commands and actual outcomes separately from pending, skipped, or blocked checks.

**Handoff:** Return submission `QUOTA-IMPL-1`, identifying `revision3`, the reviewed code state, changed files, implemented behavior, actual verification, assumptions, and limitations. Follow `workflow/templates/implementer-summary-template.md` for function purpose, inputs/results, side effects, failures/recovery, and linked tests.

Your completion report awaits independent reviewer approval; do not claim approval or update shared checkboxes. After root confirms approval of the latest submission and combined implementation/tests, write only the uniquely assigned post-approval summary file. Root will assign that path.