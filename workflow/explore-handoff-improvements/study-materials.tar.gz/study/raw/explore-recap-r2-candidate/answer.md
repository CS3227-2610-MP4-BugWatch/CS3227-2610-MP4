In this simulation, we’ve agreed that testers can explicitly save private, project-specific drafts from the first save. Other draft fields may be blank within existing limits. Saving keeps the tester on the form and shows **“Draft saved”** on success.

Drafts in archived projects remain readable and deletable. Saving edits or submitting to that archived project is rejected, but the owner can select a different active project and save to move the draft.

If the connection fails, the current text is retained for correction, readback or retry as appropriate. There is no silent automatic repost.

These are confirmed simulated decisions from the supplied fact sheet, not independently verified implementation behavior. Attachments, shared drafts and automatic saving are excluded. Only conversational exploration and recap are authorized; file writing and implementation are not.

The remaining decision is navigation with unsaved edits. I recommend warning before leaving so a tester does not accidentally lose changes, though this adds an interruption. That recommendation has not been accepted or rejected, and it blocks a complete proposal.

**When a tester tries to leave with unsaved edits, should they receive a warning with options to stay or leave and discard those edits?**