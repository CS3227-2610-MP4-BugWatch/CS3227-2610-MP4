Implement Q1 under `workflow/quota-exercise/feature-plan.md`, authoritative revision 3. Read requirement sections R1–R5 and design interface I1, plus `workflow/instructions/code-standards.md` and `handoffs.md` before editing. Retrieve further relevant context as needed; raise missing or conflicting contracts with the coordinator rather than guessing.

You exclusively own `src/features/reports/quotaPolicy.ts`. The tester owns `src/test/quota-policy.test.ts`; root owns shared configuration and task checkboxes. Preserve other writers’ changes. Agree I1 with the tester before parallel edits.

Implement this exact export:

```ts
reserveAttempt(
  attempts: readonly number[],
  nowMs: number
): { allowed: boolean; retryAfterMs: number; attempts: number[] }
```

Inputs are epoch milliseconds and admitted timestamps. Do not mutate the caller’s array. Retain only timestamps strictly greater than `nowMs - 300000`; a timestamp exactly at the cutoff expires. Return retained timestamps sorted ascending.

- If fewer than 5 timestamps remain, append `nowMs`, return `allowed: true` and `retryAfterMs: 0`.
- If already 5 remain, do not append; return `allowed: false` and `retryAfterMs: Math.max(0, oldest + 300000 - nowMs)`.

Keep this a pure helper. Do not add database access, provider calls, UI changes, dependencies, or claims of atomic multi-request admission.

Coordinate coverage with the tester for empty input, fifth/sixth admission, exact cutoff, unsorted input, and input immutability. Required checks are:

```text
npm run test -- --run src/test/quota-policy.test.ts
npm run lint
npm run build
```

Return completion submission **QUOTA-IMPL-1**, identifying **revision3**, completion status, changed files, implemented behavior, actual commands and results, and unresolved limitations or blockers. Follow `workflow/templates/implementer-summary-template.md` for function purpose, inputs/results, side effects, failures/recovery, and linked tests. No test output is currently supplied; do not imply checks have passed.

Your completion report awaits independent reviewer approval. Report coordination blockers promptly. Do not edit shared plans, checkboxes, or logs. Write the assigned post-approval summary only after the coordinator confirms approval.